import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Reads the device's compass heading (0–360°, clockwise from north) –
 * the same sensor Google Maps uses for its blue "direction beam".
 *
 *  - iOS Safari: `webkitCompassHeading` (needs a user tap to grant permission)
 *  - Android Chrome: `deviceorientationabsolute` → heading = 360 − alpha
 *
 * status: "idle" | "needs-permission" | "active" | "denied" | "unsupported" | "no-sensor"
 */
export function useCompassHeading({ smoothing = 0.2, declination = 0 } = {}) {
  const [heading, setHeading] = useState(null);
  const [accuracy, setAccuracy] = useState(null);
  const [status, setStatus] = useState("idle");

  const vec = useRef(null); // smoothed unit vector [sin, cos]
  const raf = useRef(0);
  const listening = useRef(null);
  const gotEvent = useRef(false);

  const screenAngle = () =>
    (screen.orientation && typeof screen.orientation.angle === "number"
      ? screen.orientation.angle
      : typeof window.orientation === "number"
      ? window.orientation
      : 0) || 0;

  const handle = useCallback(
    (e) => {
      let h = null;
      if (typeof e.webkitCompassHeading === "number" && !isNaN(e.webkitCompassHeading)) {
        h = e.webkitCompassHeading; // iOS, already clockwise from north
        if (typeof e.webkitCompassAccuracy === "number") setAccuracy(e.webkitCompassAccuracy);
      } else if (e.alpha != null && (e.absolute || e.type === "deviceorientationabsolute")) {
        h = 360 - e.alpha; // Android, alpha is counter-clockwise
      }
      if (h == null) return;
      gotEvent.current = true;

      h = (h + screenAngle() + declination + 360) % 360;
      const rad = (h * Math.PI) / 180;
      const s = Math.sin(rad), c = Math.cos(rad);

      // low-pass filter on the unit circle (avoids the 359°→0° jump)
      if (!vec.current) vec.current = [s, c];
      else {
        vec.current[0] += smoothing * (s - vec.current[0]);
        vec.current[1] += smoothing * (c - vec.current[1]);
      }

      if (!raf.current) {
        raf.current = requestAnimationFrame(() => {
          raf.current = 0;
          const [vs, vc] = vec.current;
          setHeading(((Math.atan2(vs, vc) * 180) / Math.PI + 360) % 360);
          setStatus("active");
        });
      }
    },
    [smoothing, declination]
  );

  const attach = useCallback(() => {
    if (listening.current) return;
    const evt = "ondeviceorientationabsolute" in window ? "deviceorientationabsolute" : "deviceorientation";
    window.addEventListener(evt, handle, true);
    listening.current = evt;
    setTimeout(() => {
      if (!gotEvent.current) setStatus((s) => (s === "active" ? s : "no-sensor"));
    }, 2500);
  }, [handle]);

  // Call from a tap/click handler (required on iOS).
  const start = useCallback(async () => {
    if (typeof window === "undefined" || typeof DeviceOrientationEvent === "undefined") {
      setStatus("unsupported");
      return;
    }
    if (typeof DeviceOrientationEvent.requestPermission === "function") {
      try {
        const res = await DeviceOrientationEvent.requestPermission();
        if (res !== "granted") return setStatus("denied");
      } catch {
        return setStatus("denied");
      }
    }
    attach();
  }, [attach]);

  useEffect(() => {
    if (typeof DeviceOrientationEvent === "undefined") setStatus("unsupported");
    else if (typeof DeviceOrientationEvent.requestPermission === "function") setStatus("needs-permission");
    else attach(); // Android / desktop: no permission prompt
    return () => {
      if (listening.current) window.removeEventListener(listening.current, handle, true);
      listening.current = null;
      cancelAnimationFrame(raf.current);
    };
  }, [attach, handle]);

  return { heading, accuracy, status, start };
}
