import { useRef, useState } from "react";
import { useCompassHeading } from "./useCompassHeading";
import plateSrc from "./luopan-plate.webp";

/* ── 24 Mountains (二十四山), clockwise from north, 15° each, 子 centred on 0° ── */
export const MOUNTAINS = [
  "子", "癸", "丑", "艮", "寅", "甲", "卯", "乙", "辰", "巽", "巳", "丙",
  "午", "丁", "未", "坤", "申", "庚", "酉", "辛", "戌", "乾", "亥", "壬",
];
const CARDINALS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
  "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];

export const mountainAt = (deg) => MOUNTAINS[Math.floor((((deg + 7.5) % 360) + 360) % 360 / 15)];
const cardinalAt = (deg) => CARDINALS[Math.round(deg / 22.5) % 16];

/* Geometry of the supplied plate image (800×800 px) */
const PLATE = { cx: 401, cy: 398, window: 108 };
// The photo has 0° (子 / North) at 3 o'clock; rotate −90° so North sits at 12 o'clock.
const IMAGE_ROTATION = -90;

/** Keeps a continuous angle so CSS transitions never spin the long way round 359°→0°. */
function useUnwrapped(angle) {
  const ref = useRef({ last: null, total: 0 });
  if (angle == null) return ref.current.total;
  const r = ref.current;
  if (r.last == null) r.total = angle;
  else r.total += ((angle - r.last + 540) % 360) - 180;
  r.last = angle;
  return r.total;
}

/**
 * <LuoPanCompass />
 *  mode = "dial"   → plate turns so its rings line up with the real world (like Google Maps
 *                    in compass mode); read your facing direction under the red top line.
 *  mode = "needle" → plate stays still, only the needle swings to point North.
 */
export default function LuoPanCompass({
  size = 360,
  mode: initialMode = "dial",
  declination = 0,
  src = plateSrc,
  showControls = true,
}) {
  const { heading, accuracy, status, start } = useCompassHeading({ declination });
  const [manual, setManual] = useState(0);
  const [mode, setMode] = useState(initialMode);

  const live = heading != null;
  const h = live ? heading : manual;
  const turn = useUnwrapped(h);

  const dialRot = mode === "dial" ? -turn : 0;   // whole plate
  const needleRot = mode === "dial" ? 0 : -turn; // needle, inside plate frame

  const facing = mountainAt(h);
  const sitting = mountainAt((h + 180) % 360);

  return (
    <div className="lp-root" style={{ width: size }}>
      <svg viewBox="0 0 800 800" width={size} height={size} className="lp-svg" role="img"
        aria-label={`Luo pan compass, facing ${Math.round(h)} degrees, ${facing} mountain`}>
        <defs>
          <radialGradient id="lp-face" cx="50%" cy="45%" r="60%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="100%" stopColor="#ece8e4" />
          </radialGradient>
          <linearGradient id="lp-steel" x1="0" x2="1">
            <stop offset="0%" stopColor="#8e959c" />
            <stop offset="50%" stopColor="#e9edf0" />
            <stop offset="100%" stopColor="#7a8188" />
          </linearGradient>
          <radialGradient id="lp-cap" cx="40%" cy="35%" r="70%">
            <stop offset="0%" stopColor="#fff3c4" />
            <stop offset="55%" stopColor="#c9a24a" />
            <stop offset="100%" stopColor="#7d5d1d" />
          </radialGradient>
          <filter id="lp-shadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="6" stdDeviation="8" floodOpacity="0.45" />
          </filter>
        </defs>

        {/* ── Rotating plate (天盤) ── */}
        <g className="lp-turn" style={{ transform: `rotate(${dialRot}deg)` }}>
          <g filter="url(#lp-shadow)">
            {/* original rings, untouched – just centred and turned so 子 is at the top */}
            <image href={src} width="800" height="800"
              transform={`translate(400 400) rotate(${IMAGE_ROTATION}) translate(${-PLATE.cx} ${-PLATE.cy})`} />
          </g>

          {/* centre window: repaint face so the printed needle is replaced by a live one */}
          <circle cx="400" cy="400" r={PLATE.window - 2} fill="url(#lp-face)" />
          <g stroke="#e8643f" fill="none">
            <circle cx="400" cy="400" r="84" strokeWidth="2" />
            {Array.from({ length: 72 }, (_, i) => (
              <line key={i} x1="400" y1={400 - 84} x2="400" y2={400 - (i % 2 ? 90 : 95)}
                strokeWidth="2" transform={`rotate(${i * 5} 400 400)`} />
            ))}
            {Array.from({ length: 8 }, (_, i) => (
              <line key={i} x1="400" y1="400" x2="400" y2="320" strokeWidth="2.5"
                strokeDasharray="10 7" transform={`rotate(${i * 45} 400 400)`} />
            ))}
          </g>
          <g fill="#e8643f" fontFamily="'Noto Serif SC','Songti SC',serif" fontSize="20"
            fontWeight="700" textAnchor="middle" dominantBaseline="central">
            <text x="400" y="333">北</text>
            <text x="467" y="400">東</text>
            <text x="400" y="467">南</text>
            <text x="333" y="400">西</text>
          </g>

          {/* needle */}
          <g className="lp-turn" style={{ transform: `rotate(${needleRot}deg)` }}>
            <polygon points="400,318 409,400 400,410 391,400" fill="#c8312b" />
            <polygon points="400,482 409,400 400,390 391,400" fill="url(#lp-steel)" stroke="#5c636a" strokeWidth="1" />
            <circle cx="400" cy="336" r="5" fill="none" stroke="#fff" strokeWidth="2" />
            <circle cx="400" cy="400" r="13" fill="url(#lp-cap)" stroke="#6b4e17" strokeWidth="1.5" />
          </g>
        </g>

        {/* ── Fixed red cross-hair (天心十道) – read the facing direction at the top ── */}
        <g pointerEvents="none">
          <line x1="400" y1="6" x2="400" y2="290" stroke="#d6261c" strokeWidth="3" />
          <line x1="400" y1="510" x2="400" y2="794" stroke="#d6261c" strokeWidth="2" opacity=".55" />
          <line x1="6" y1="400" x2="290" y2="400" stroke="#d6261c" strokeWidth="2" opacity=".55" />
          <line x1="510" y1="400" x2="794" y2="400" stroke="#d6261c" strokeWidth="2" opacity=".55" />
          <polygon points="400,22 386,0 414,0" fill="#d6261c" />
        </g>
      </svg>

      <div className="lp-readout">
        <div className="lp-deg">{h.toFixed(1)}°<span>{cardinalAt(h)}</span></div>
        <div className="lp-mtn">
          <div><small>向 Facing</small><b>{facing}</b></div>
          <div><small>坐 Sitting</small><b>{sitting}</b></div>
        </div>
      </div>

      {showControls && (
        <div className="lp-controls">
          {status === "needs-permission" && (
            <button className="lp-btn primary" onClick={start}>Enable compass</button>
          )}
          {(status === "denied" || status === "unsupported" || status === "no-sensor") && (
            <p className="lp-note">
              {status === "denied" ? "Compass permission was denied. Allow Motion & Orientation access in browser settings."
                : "No compass sensor found here – drag the slider to try it, or open on a phone."}
            </p>
          )}
          {!live && (
            <input className="lp-slider" type="range" min="0" max="359.9" step="0.5" value={manual}
              onChange={(e) => setManual(+e.target.value)} aria-label="Simulated heading" />
          )}
          {live && accuracy != null && accuracy > 20 && (
            <p className="lp-note">Low accuracy (±{Math.round(accuracy)}°) – wave the phone in a figure-8 to calibrate.</p>
          )}
          <div className="lp-seg">
            <button className={mode === "dial" ? "on" : ""} onClick={() => setMode("dial")}>Turn plate</button>
            <button className={mode === "needle" ? "on" : ""} onClick={() => setMode("needle")}>Turn needle</button>
          </div>
        </div>
      )}
    </div>
  );
}
