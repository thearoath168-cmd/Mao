import LuoPanCompass from "./LuoPanCompass";
import "./LuoPanCompass.css";

export default function App() {
  const size = Math.min(window.innerWidth - 32, 440);
  return (
    <main className="app">
      <h1>羅盤 <span>Luo Pan Compass</span></h1>
      <LuoPanCompass size={size} />
      <p className="hint">Hold the phone flat, top edge pointing where you face. Keep away from metal and magnets.</p>
    </main>
  );
}
