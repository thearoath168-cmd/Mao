# Luo Pan Compass (React)

Your luo pan plate image as a live compass, driven by the phone's heading sensor (the same one Google Maps uses).

```bash
npm install
npm run dev      # open the "Network" URL on your phone
```

**HTTPS is required on phones** for the compass sensor. Use `npm run build` and deploy (Vercel, Netlify, GitHub Pages),
or tunnel the dev server with e.g. `npx localtunnel --port 5173`.

## Use the component elsewhere

Copy `src/LuoPanCompass.jsx`, `src/useCompassHeading.js`, `src/LuoPanCompass.css`, `src/luopan-plate.webp`.

```jsx
import LuoPanCompass from "./LuoPanCompass";
import "./LuoPanCompass.css";

<LuoPanCompass size={360} mode="dial" />   // mode: "dial" (plate turns) | "needle" (needle turns)
```

Props: `size`, `mode`, `declination` (degrees to add for true north; leave 0 for magnetic, which is traditional for luo pan), `src`, `showControls`.

- iOS shows an **Enable compass** button (Apple requires a tap to grant motion access).
- On desktop there is no sensor, so a slider simulates the heading.
